//
//  ViewController.swift
//  StepTracker
//
//  Created by Arsh Beri on 19/07/25.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

