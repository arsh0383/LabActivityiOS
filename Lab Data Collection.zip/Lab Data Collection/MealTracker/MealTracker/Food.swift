import Foundation
struct Food{
    var name: String
    var description: String
    
}

