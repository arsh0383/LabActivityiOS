//
//  CalculatorTests.swift
//  CalculatorTests
//
//  Created by Arsh Beri on 17/07/25.
//

import Testing
@testable import Calculator

struct CalculatorTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
